"""InkSoul 命令行入口。

子命令：
  inksoul analyze  <文件|目录|->         结构与文体分析（默认文本报告）
  inksoul generate <创作要求>            调用模型生成并自检修订（需配置 API Key）
  inksoul plan     <创作要求>            只输出文体规划（不调模型）
  inksoul baseline build <目录> --genre  构建体裁基线
  inksoul doctor                         环境自检
  inksoul --version                      版本

退出码：0 成功；1 输入/配置/分析错误（InkSoulError）；2 未预期错误；3 模型接口失败。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .config import InkSoulConfig, load_config
from .errors import InkSoulError, ModelAPIError
from .logging_setup import setup_logging


def _read_inputs(target: str) -> list[tuple[str, str]]:
    """返回 [(名字, 文本)]。目录会递归收集 .txt/.md。"""
    if target == "-":
        return [("<stdin>", sys.stdin.read())]
    p = Path(target).expanduser()
    if p.is_file():
        return [(str(p), p.read_text(encoding="utf-8"))]
    if p.is_dir():
        out = []
        for f in sorted(list(p.rglob("*.txt")) + list(p.rglob("*.md"))):
            try:
                out.append((str(f), f.read_text(encoding="utf-8")))
            except OSError:
                continue
        if not out:
            raise InkSoulError(f"目录里没有 .txt/.md 文件：{p}", hint="把待分析的中文文本放进该目录")
        return out
    raise InkSoulError(f"路径不存在：{p}", hint="检查文件路径，或用 - 从标准输入读取")


def _fmt_report(rep) -> str:
    d = rep.as_dict()
    f = d["fingerprint"]
    lines = [
        "== 概览 ==",
        f"后端 {d['meta']['backend']}（依存句法：{'有' if d['meta']['has_dependency'] else '无'}）"
        f"｜段落 {d['meta']['paragraphs']}｜句 {d['meta']['sentences']}｜小句 {d['meta']['clauses']}｜字数 {d['meta']['chars']}",
        "",
        "== 句法指纹 ==",
        f"不同骨架 {f['distinct_patterns']} 种，模式熵 {f['pattern_entropy']}，复用率 {f['reuse_rate']:.0%}",
    ]
    for p in f["top_patterns"][:5]:
        lines.append(f"  {p['share']:.0%}  {p['signature']}  ×{p['count']}")
    if f["suspects"]:
        lines.append("")
        lines.append("== 机械复用嫌疑 ==")
        for s in f["suspects"][:5]:
            lines.append(f"  ×{s['freq']} 跨段{s['para_spread']} 间距变异{s['gap_cv']}  {s['signature']}")
            for ev in s["evidence"][:2]:
                lines.append(f"      · {ev}")
    div = d.get("diversity") or {}
    if not div.get("unavailable"):
        lines.append("")
        lines.append("== 句法多样性 ==")
        for key in ("adjacent_similarity_mean", "paragraph_internal_repeat_rate", "cross_paragraph_reuse_rate"):
            if key in div:
                lines.append(f"  {key} = {div[key]}")
    sty = d.get("style") or {}
    if not sty.get("unavailable"):
        lines.append("")
        lines.append("== 文体 ==")
        for key in ("ttr", "dialogue_ratio", "sentence_length_stats"):
            if key in sty:
                lines.append(f"  {key} = {sty[key]}")
    rev = d.get("review") or {}
    if rev and not rev.get("unavailable"):
        lines.append("")
        lines.append("== 审阅意见 ==")
        counts = rev.get("severity_counts") or {}
        lines.append(f"  问题 {len(rev.get('issues', []))} 条｜严重度 {counts}")
        for it in rev.get("issues", [])[:8]:
            lines.append(f"  [{it.get('severity')}] {it.get('kind')}：{it.get('text', '')[:30]}")
            if it.get("suggestion"):
                lines.append(f"      → {it['suggestion']}")
    for note in (div.get("notes") or [])[:3] + (sty.get("notes") or [])[:2]:
        lines.append(f"注：{note}")
    return "\n".join(lines)


def cmd_analyze(args) -> int:
    cfg = load_config(args.config)
    setup_logging(cfg)
    from .analyzer import Analyzer, AnalysisReport

    analyzer = Analyzer(cfg)
    baseline = None
    if args.baseline:
        from . import fingerprint as fp

        baseline = fp.Baseline(**json.loads(Path(args.baseline).read_text(encoding="utf-8")))
    inputs = _read_inputs(args.target)
    reports = []
    for name, text in inputs:
        try:
            rep = analyzer.analyze(text, with_review=not args.no_review, baseline=baseline)
        except InkSoulError as exc:
            print(f"[{name}] 分析失败：{exc}", file=sys.stderr)
            continue
        reports.append((name, rep))
    if not reports:
        return 2
    if args.json:
        payload = {name: rep.as_dict() for name, rep in reports}
        print(json.dumps(payload if len(payload) > 1 else next(iter(payload.values())),
                         ensure_ascii=False, indent=2))
    else:
        for name, rep in reports:
            if len(reports) > 1:
                print(f"\n######## {name} ########")
            print(_fmt_report(rep))
    return 0


def cmd_plan(args) -> int:
    cfg = load_config(args.config)
    setup_logging(cfg)
    from .generation import GenerationController

    if getattr(args, "target_chars", 0):
        cfg.generation.target_chars = int(args.target_chars)
    plan = GenerationController(cfg).plan(args.brief, genre=args.genre, perspective=args.perspective)
    print(json.dumps(plan.as_dict() if hasattr(plan, "as_dict") else plan, ensure_ascii=False, indent=2))
    return 0


def cmd_generate(args) -> int:
    cfg = load_config(args.config)
    setup_logging(cfg)
    from .generation import GenerationController

    if getattr(args, "target_chars", 0):
        cfg.generation.target_chars = int(args.target_chars)
    ctrl = GenerationController(cfg)
    try:
        result = ctrl.generate(args.brief, genre=args.genre, perspective=args.perspective,
                               max_rounds=args.rounds, offline=args.offline)
    except ModelAPIError as exc:
        print(f"生成失败：{exc}", file=sys.stderr)
        if exc.hint:
            print(f"提示：{exc.hint}", file=sys.stderr)
        return 3
    out = Path(args.out).expanduser() if args.out else None
    if out:
        out.write_text(result.text, encoding="utf-8")
        print(f"已写入 {out}")
    else:
        print(result.text)
    if args.report:
        print("\n== 生成后自检 ==")
        for item in result.analysis:
            print(json.dumps(item, ensure_ascii=False)[:800])
    return 0


def cmd_baseline(args) -> int:
    from . import fingerprint as fp

    inputs = _read_inputs(args.target)
    baseline = fp.build_baseline([t for _, t in inputs], args.genre, source=args.target)
    out = Path(args.out).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(baseline.as_dict())
    payload["patterns"] = [{"signature": " ".join(p), "count": n} for p, n in baseline.patterns.most_common()]
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"基线已写入 {out}：{baseline.n_clauses} 小句 / {len(baseline.patterns)} 种骨架 / tau={baseline.tau:.2f}")
    return 0


def cmd_doctor(args) -> int:
    import platform
    import shutil

    print(f"InkSoul {__version__}｜Python {platform.python_version()}｜{platform.machine()}")
    cfg = load_config(args.config)
    print(f"配置目录：{cfg.home}")
    ok = True
    for mod in ("jieba",):
        print(f"  {mod}: {'✔' if shutil.which('python3') and _has(mod) else '✘ 缺失'}")
        ok = ok and _has(mod)
    try:
        from .nlp.backend import build_backend

        be = build_backend(cfg.analysis.backend)
        print(f"  NLP 后端：{be.name} {be.version}（依存：{be.has_dependency}）")
    except InkSoulError as exc:
        ok = False
        print(f"  NLP 后端：不可用（{exc}）")
    print(f"  模型：{cfg.model.model} @ {cfg.model.base_url}｜Key：{'已配置' if cfg.model.api_key else '未配置'}")
    print("结论：" + ("核心功能可用" if ok else "缺少核心依赖，见上面 ✘"))
    return 0 if ok else 2


def _has(mod: str) -> bool:
    try:
        __import__(mod)
        return True
    except ImportError:
        return False


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="inksoul", description="InkSoul · 面向 AI Agent 的中文文学创作增强工具")
    p.add_argument("--version", action="version", version=f"inksoul {__version__}")
    p.add_argument("--config", help="配置文件路径（默认 ~/.inksoul/config.json）")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("analyze", help="分析文本的句法/文体特征")
    a.add_argument("target", help="文件、目录或 - （标准输入）")
    a.add_argument("--json", action="store_true", help="输出 JSON")
    a.add_argument("--no-review", action="store_true", help="跳过审阅意见")
    a.add_argument("--baseline", help="体裁基线 JSON 路径")
    a.set_defaults(func=cmd_analyze)

    g = sub.add_parser("generate", help="按创作要求生成并自检修订")
    g.add_argument("brief", help="创作要求")
    g.add_argument("--genre", default=None)
    g.add_argument("--perspective", default=None)
    g.add_argument("--rounds", type=int, default=2)
    g.add_argument("--out", default=None)
    g.add_argument("--target-chars", type=int, default=0, help="目标篇幅（字）")
    g.add_argument("--offline", action="store_true", help="不调模型，只校验配置")
    g.add_argument("--report", action="store_true", help="打印生成后自检")
    g.set_defaults(func=cmd_generate)

    pl = sub.add_parser("plan", help="只输出文体规划")
    pl.add_argument("brief")
    pl.add_argument("--genre", default=None)
    pl.add_argument("--perspective", default=None)
    pl.add_argument("--target-chars", type=int, default=0)
    pl.set_defaults(func=cmd_plan)

    b = sub.add_parser("baseline", help="体裁基线")
    bsub = b.add_subparsers(dest="bcmd", required=True)
    bb = bsub.add_parser("build", help="从语料构建基线")
    bb.add_argument("target")
    bb.add_argument("--genre", required=True)
    bb.add_argument("--out", default=str(Path.home() / ".inksoul" / "baseline.json"))
    bb.set_defaults(func=cmd_baseline)

    d = sub.add_parser("doctor", help="环境自检")
    d.set_defaults(func=cmd_doctor)
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args) or 0)
    except InkSoulError as exc:
        print(f"错误：{exc}", file=sys.stderr)
        if exc.hint:
            print(f"提示：{exc.hint}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("已中断", file=sys.stderr)
        return 130
    except Exception as exc:  # noqa: BLE001
        print(f"未预期错误：{type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
